import BaseToCore "BaseToCore";
import OrderedMap "mo:base/OrderedMap";
import Map "mo:core/Map";
import Text "mo:core/Text";

module {
  type OldActor = {
    var highScores : OrderedMap.Map<Text, Nat>;
    var gamesPlayed : Nat;
  };

  type NewActor = {
    var highScores : Map.Map<Text, Nat>;
    var gamesPlayed : Nat;
  };

  public func run(old : OldActor) : NewActor {
    {
      var highScores = BaseToCore.migrateOrderedMap(old.highScores);
      var gamesPlayed = old.gamesPlayed;
    };
  };
};
