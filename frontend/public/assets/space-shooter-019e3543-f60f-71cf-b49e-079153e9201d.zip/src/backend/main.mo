import Map "mo:core/Map";
import Text "mo:core/Text";
import Migration "migration";

(with migration = Migration.run)
actor {
  var highScores = Map.empty<Text, Nat>();
  var gamesPlayed = 0;

  public func submitScore(playerName : Text, score : Nat) : async () {
    highScores.add(playerName, score);
  };

  public query func getHighScores() : async [(Text, Nat)] {
    highScores.entries().toArray();
  };

  public func incrementGamesPlayed() : async Nat {
    gamesPlayed += 1;
    gamesPlayed;
  };

  public query func getGamesPlayed() : async Nat {
    gamesPlayed;
  };
};
