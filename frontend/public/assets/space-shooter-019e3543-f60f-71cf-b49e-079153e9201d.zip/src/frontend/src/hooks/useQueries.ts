import { createActor } from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export function useHighScores() {
  const { actor, isFetching } = useActor(createActor);

  return useQuery<Array<[string, bigint]>>({
    queryKey: ["highScores"],
    queryFn: async () => {
      if (!actor) return [];
      const scores = await actor.getHighScores();
      return scores.sort((a, b) => Number(b[1] - a[1]));
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSubmitScore() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      playerName,
      score,
    }: { playerName: string; score: bigint }) => {
      if (!actor) throw new Error("Actor not initialized");
      await actor.submitScore(playerName, score);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["highScores"] });
    },
  });
}

export function useGamesPlayed() {
  const { actor, isFetching } = useActor(createActor);

  return useQuery<bigint>({
    queryKey: ["gamesPlayed"],
    queryFn: async () => {
      if (!actor) return BigInt(0);
      return await actor.getGamesPlayed();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useIncrementGamesPlayed() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not initialized");
      return await actor.incrementGamesPlayed();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["gamesPlayed"] });
    },
  });
}
